﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace ConsoleApplication1
{
    class Program
    {
        struct Numbers
        {
            public int val;

            public Numbers(int _val) { val = _val; }
            public override string ToString()
            { return val.ToString(); }
        }

        static void Main(string[] args)
        {
            Numbers n1 = new Numbers(0);
            Numbers n2 = n1;
            n1.val += 1;
            n2.val += 2;
            Console.WriteLine("n1 = {0}, n2 = {1}", n1, n2);
            //0
            //System.Text.StringBuilder sb = new System.Text.StringBuilder(30); sb.Append("wombat");       // Построение строки 
            //sb.Append(" kangaroo"); sb.Append(" wallaby"); sb.Append(" koala");
            //string s = sb.ToString();	// Копирование результата в строку
            //Console.WriteLine(s);

            //1

            //// Объявление и инициализация массива 
            //int[] ar = { 3, 1, 2 };

            //// Вызов общего или статического метода 
            //Array.Sort(ar);

            //// Отображение результата
            //Console.WriteLine("{0}. {1}, {2}", ar[0], ar[1], ar[2]);

            //2

            //// Создание текстового файла и запись в него 
            //StreamWriter sw = new StreamWriter("text.txt");
            //sw.WriteLine("Hello, World!");
            //sw.Close();

            //// Чтение и отображение текстового файла 
            //StreamReader sr = new StreamReader("text.txt");
            //Console.WriteLine(sr.ReadToEnd());
            //sr.Close();

            //3

            //try
            //{
            //    StreamReader sr = new StreamReader(@"C:\boot.ini"); Console.WriteLine(sr.ReadToEnd());
            //}
            ////catch (System.IO.FileNotFoundException)
            ////{
            ////    Console.WriteLine("The file could not be found.");
            ////}
            ////catch (System.UnauthorizedAccessException)
            ////{
            ////    Console.WriteLine("You do not have sufficient permissions.");
            ////}
            //catch (Exception ex)
            //{
            //    // Если при чтении файла возникнут сбои, появится сообщение об ошибке 
            //    Console.WriteLine("Error reading file: " + ex.Message);
            //}

            ////4
            //StreamReader sr = new StreamReader("text.txt");
            //try
            //{
            //    Console.WriteLine(sr.ReadToEnd());
            //}
            //catch (Exception ex)
            //{
            //    // Если возник сбой при чтении файла, выводится сообщение об ошибке 
            //    Console.WriteLine("Error reading file: " + ex.Message);
            //}
            //finally
            //{
            //    // Закрываем StreamReader, независимо от того, возникло исключение или нет
            //    sr.Close();
            //}




        }
    }
}
