﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Convert
{
    class Program
    {

        #region #2

        //struct TypeA
        //{
        //    public int Value;
        //    // Разрешает неявное преобразование из целочисленного типа 
        //    public static implicit operator TypeA(int arg)
        //    {
        //        TypeA res = new TypeA();
        //        res.Value = arg; 
        //        return res;
        //    }
        //    // Разрешается явное преобразование в целочисленный тип
        //    public static explicit operator int(TypeA arg)
        //    {
        //        return arg.Value;
        //    }

        //    // Обеспечивает преобразование строк (избегая упаковки)
        //    public override string ToString()
        //    {
        //        return this.Value.ToString();

        //    }
        //}

        #endregion
        
        static void Main(string[] args)
        {
            #region #1
            ////неявное преобразование
            //int i = 1;
            //double d = 1.0001;
            //d = i;    // Преобразование допускается



            ////Упаковка
            //int k = 123;
            //object o = (object)k;

            ////Распаковка
            //object ob = 123;
            //int j = (int)0;
            
            #endregion

            #region #2
            //TypeA a;
            //int i;
            //// Неявное расширяющее преобразование разрешено 
            //a = 42;   
            //// но не  a.Value = 42;
            //// Сужающее преобразование должно быть явным 
            //i = (int)a; 
            //// но не i = a.Value;
            //Console.WriteLine("а = {0}, i = {0}", a.ToString(), i.ToString());
            
            #endregion
        }
    }
}
