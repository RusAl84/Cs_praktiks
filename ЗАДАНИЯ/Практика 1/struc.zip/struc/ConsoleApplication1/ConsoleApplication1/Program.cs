﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        struct Cycle
        {
            // Закрытые поля 
            int _val, _min, _max;

            // Конструктор
            public Cycle(int min, int max)
            {
                _val = min; _min = min; _max = max;
            }
            public int Value
            {
                get { return _val; }
                set
                {
                    if (value > _max) _val = _min;
                    else
                    {
                        if (value < _min) _val = _max;
                        else
                            _val = value;
                    }
                }
            }
            public override string ToString()
            {
                return Value.ToString();
            }
            public int ToInteger()
            {
                return Value;
            }
            // Операторы (новинка .NET 2.0)
            public static Cycle operator +(Cycle argl, int arg2)
            {
                argl.Value += arg2; return argl;
            }
            public static Cycle operator -(Cycle argl, int arg2)
            {
                argl.Value -= arg2; return argl;
            }
        }
        static void Main(string[] args)
        {
            //Cycle degrees = new Cycle(0, 359);
            //Cycle quarters = new Cycle(1, 4);
            //for (int i = 0; i <= 8; i++)
            //{
            //    degrees += 90; quarters += 1;
            //    Console.WriteLine("degrees = {0}, quarters = {1}", degrees, quarters);
            //}
        }
    }
}
