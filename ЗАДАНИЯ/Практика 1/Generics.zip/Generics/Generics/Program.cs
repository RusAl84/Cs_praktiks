﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Generics
{
    #region // #1

    class Obj
    {
        public Object t;
        public Object u;
        public Obj(Object _t, Object _u)
        {
            t = _t; u = _u;
        }
    }

    class Gen<T, U>
    {
        public T t;
        public U u;
        public Gen(T _t, U _u)
        {
            t = _t;
            u = _u;
        }
    }
    #endregion

    #region #3

    class CompGen<T>
        where T : IComparable
    {
        public T t1; public T t2;

        public CompGen(T _t1, T _t2)
        {
            t1 = _t1; t2 = _t2;
        }
        public T Max()
        {
            if (t2.CompareTo(t1) < 0) return t1;
            else
                return t2;
        }
    }

    #endregion

    class Program
    {
        static void Main(string[] args)
        {
            #region // #1
            // Add two strings using the Obj class
            Obj oa = new Obj("Hello, ", "World!");
            Console.WriteLine((string)oa.t + (string)oa.u);

            // Add two strings using the Gen class
            Gen<string, string> ga = new Gen<string, string>("Hello, ", "World!");
            Console.WriteLine(ga.t + ga.u);

            // Add a double and an int using the Obj class
            Obj ob = new Obj(10.125, 2005);
            Console.WriteLine((double)ob.t + (int)ob.u);

            // Add a double and an int using the Gen class
            Gen<double, int> gb = new Gen<double, int>(10.125, 2005);
            Console.WriteLine(gb.t + gb.u);
            #endregion

            #region #2
            //// Add a double and an int using the Gen class
            //Gen<double, int> gc = new Gen<double, int>(10.125, 2005);
            //Console.WriteLine(gc.t + gc.u);
            //// Add a double and an int using the Obj class
            //Obj oc = new Obj(10.125, 2005);
            //Console.WriteLine((int)oc.t + (int)oc.u);
            #endregion
        }
    }
}
