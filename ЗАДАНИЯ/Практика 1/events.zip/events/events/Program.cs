﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace events
{
    delegate void MyEventHendler(object sender, EventArgs e);
    class obj
    {
        int a;
        public event MyEventHendler MyEvent;
        public obj()
        {
            a = 0;

        }
        public void inc(int _a)
        {
            a += _a;
            if (a > 10)
            {
                if (MyEvent != null)
                    MyEvent(this, new EventArgs());
            }
        }
    }

    class Program
    {

        static void Main(string[] args)
        {
            obj ob = new obj();
            ob.MyEvent += new MyEventHendler(ob_MyEvent);
            ob.inc(3);
            ob.inc(3);
            ob.inc(3);
            ob.inc(3);

        }

        static void ob_MyEvent(object sender, EventArgs e)
        {
            Console.WriteLine("Привет");
        }
    }
}
