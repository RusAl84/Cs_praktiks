﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CustomClasses
{
    //Новый класс позволяет генерировать и перехватывать новое исключение, так как наследует соответствующие функции от своего базового класса:
    // #1
    //class DerivedException : System.ApplicationException
    //{
    //    public override string Message
    //    {
    //        get { return "An error occurred in the application."; }
    //    }
    //}

#region    // #2
    //interface IMessage
    //{
    //    // Отправка сообщения. Возвращает True при успехе и False в противном случае 
    //    bool Send();
    //    // Отправляемое сообщение, 
    //    string Message { get; set; } 
    //    // Адрес для отправки, 
    //    string Address { get;  set; }
    //}
    
    // #2
    //class EmailMessage : IMessage {
#endregion

    class Program
    {
        static void Main(string[] args)
        {
            // #1
            //try
            //{
            //    throw new DerivedException();
            //}
            //catch (DerivedException ex)
            //{
            //    Console.WriteLine("Source; {0}, Error: {1}", ex.Source, ex.Message);
            //}

        }
    }
}
